create
    definer = root@localhost function rand_name(n int, l int) returns varchar(255)
begin
 declare return_str varchar(255) default '';
 declare i int default 0;
 while i < n do 
 if i=0 then
 set return_str = rand_string(l);
 else
 set return_str =concat(return_str,concat(' ', rand_string(l)));
 end if;
 set i = i + 1;
 end while;
 return return_str;
 end;

