create
    definer = root@localhost function rand_string(n int) returns varchar(255)
begin
 declare lower_str varchar(100) default
 'abcdefghijklmnopqrstuvwxyz';
 declare upper_str varchar(100) default
 'ABCDEFJHIJKLMNOPQRSTUVWXYZ';
 declare return_str varchar(255) default '';
 declare i int default 0;
 declare tmp int default 5+rand_num(n);
 while i < tmp do 
 if i=0 then
 set return_str 
=concat(return_str,substring(upper_str,floor(1+rand()*26),1));
 else
 set return_str 
=concat(return_str,substring(lower_str,floor(1+rand()*26),1));
 end if;
 
 set i = i + 1;
 end while;
 return return_str;
 end;

