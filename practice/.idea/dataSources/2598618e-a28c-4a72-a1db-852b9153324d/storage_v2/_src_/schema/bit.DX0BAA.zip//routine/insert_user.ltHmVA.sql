create
    definer = root@localhost procedure insert_user(IN start int(10), IN max_num int(10))
begin
declare i int default 0; 
set autocommit = 0; 
 repeat
 set i = i + 1;
 insert into test_user values ((start+i) ,rand_name(2, 
5),rand_num(120),CURRENT_TIMESTAMP);
 until i = max_num
 end repeat;
 commit;
end;

